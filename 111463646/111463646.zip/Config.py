UNKNOWN = "UNK"
ROOT = "ROOT"
NULL = "NULL"
NONEXIST = -1

max_iter = 1001
batch_size = 10000
hidden_size = 100
embedding_size = 50
learning_rate = 0.003
display_step = 100
validation_step = 500
n_Tokens = 48
lam = 1e-8
